<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <script src = "js/bootsrap.js"></script>
    <link rel="stylesheet" type="text/css" href="css/font-awesome/css/font-awesome.min.css">
    <script src="js/jquery.js"></script>

</head>
<body>

<div class="textword_about" data-link="first">

 <?php
                                include 'db.php';

                                $sql = "SELECT * FROM employees";
                                $get = mysqli_query($con,$sql);

                                echo "<div class='table-responsive'>";    
                                echo "<table class='table table-striped table-bordered'>
                                	<tr>
                                	<th>No.</th>
                                	<th>School Number</th>
                                	<th>school Name</th>
                                	<th>Email</th>
                                	<th>Mobile Number</th>
                                	<th>Current Status</th>
                                	</tr>";

                                echo "
                                      <tr>
                                        <td>1</td>
                                        <td>555</td>
                                        <td>Tambaza Secondary School</td>
                                        <td>tambaza@gmail.com</td>
                                        <td>0756342311</td>
                                        <td>Active</td>
                                      </tr>
                                ";
                                echo "
                                      <tr>
                                        <td>2</td>
                                        <td>556</td>
                                        <td>Changombe Secondary School</td>
                                        <td>changombe556@gmail.com</td>
                                        <td>076834434</td>
                                        <td>Active</td>
                                      </tr>
                                ";

                               /* while ($record = mysqli_fetch_array($get)) {
                                	echo "<tr>";
                                	echo "<td>" . $record['Index'] . "</td>";
                                	echo "<td>" . $record['EmpNo'] . "</td>";
                                	echo "<td>" . $record['Name'] . "</td>";
                                	echo "<td>" . $record['Email'] . "</td>";
                                	echo "<td>" . $record['MobileNo'] . "</td>";
                                	echo "<td>" . $record['Currently'] . "</td>";
                                	echo "</tr>";
                                }*/
                                echo "</table></div>";
                                	




                        ?>
                        </div>

</body>
</html>